import "./style.css";

const Header = () => {
    return (
		<header className="header">
			<div className="header__wrapper">
				<h1 className="header__title">
					<strong>
						Hi, my name is <em>Angelina</em>
					</strong>
					<br />a frontend developer and Genshin enjoyer
				</h1>
				<div className="header__text">
					<p>Student of It Step University</p>
				</div>
				<a href="#!" className="btn">
					Info About Me
				</a>
			</div>
		</header>
	);
}

export default Header;